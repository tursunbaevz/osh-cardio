@extends('layouts.master')

@section('content')
@include ('layouts.navForPosts')

@endsection