<?php $__env->startSection('content'); ?>
	<h1 class="title">Новости</h1>

		<table class="table table-hover table-style" id="post_table">
		  <thead>
		    <tr class="p-3 mb-2 bg-danger text-white">
		     	<th scope="col">#</th>
		     	<th scope="col">Наименование</th>
		     	<th scope="col">Текст</th>
		        <th scope="col">дата создания</th>
		        <th scope="col"><div class="float-btn">
				<a href="<?php echo e('/adminpanel/dashboard/posts/create'); ?>" class="btn btn-success">
			   		<i class="fas fa-plus" aria-hidden="true"></i></a>
				</div>
			    </th>
		
		    </tr>
		  </thead>  

		  <tbody>
		    <?php $i = 1; ?>
			<?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			    
			    <tr>
			      	<th scope="row"><?php echo e($i); ?> </th>
			      	<td><?php echo str_limit($post->title, 25); ?></td>
			      	<td><?php echo str_limit(strip_tags($post->body), 50); ?></td>
			      	<td><?php echo e(($post->created_at)->diffForHumans()); ?></td>
			      	<td style="width: 120px;"><a href="<?php echo e(action('Adminpanel\Posts@edit', $post->id)); ?>"		 		class="btn btn-primary">
			      			<i class="fas fa-edit"></i>
			      		</a> 

						<a class="btn btn-danger deletebtn" href="javascript:void(0)" data-post="<?php echo e($post->id); ?>">
							<i class="fas fa-minus"></i>
						</a>
			      	</td>
			      	<td style="display: none;"> <?php echo e($i++); ?></td>
			    </tr>
			   
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		  </tbody>
		</table>
	
<?php $__env->stopSection(); ?>


<?php $__env->startSection('script'); ?>

<script> 
  $(document).on('click', '.deletebtn', function(ev){ 
      var postid = $(this).attr("data-post"); 
      var clickedObj = $(this).parent().parent(); 
      if (confirm('Вы уверены?')) {   
        $.ajax({ 
            method: 'DELETE', 
            url: '<?php echo e(url('/adminpanel/dashboard/posts')); ?>', 
            dataType: 'text', 
            headers: { 'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content') }, 
            data: {id:postid,"_token": "<?php echo e(csrf_token()); ?>"}, 
 
            success: function (data) { 
            $(clickedObj).fadeOut( "slow", function() { 
              // удалено 
            }); 
            } 
        });   
    }  
  }); 
</script> 

<?php $__env->stopSection(); ?>




<?php echo $__env->make('adminLayouts.admin_master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>