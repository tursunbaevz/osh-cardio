<?php $__env->startSection('content'); ?>
<div class="col" style="margin: auto; margin-bottom: 50px;">

	<form method="POST" action="<?php echo e(action('Adminpanel\AlbumsController@update', $album)); ?>" enctype="multipart/form-data">

		  <?php echo e(csrf_field()); ?>


		  <div class="form-group">
		    <br>
		    <input name="name" value="<?php echo e($album->name); ?>" type="text" class="form-control" placeholder="Введите заголовок">
		  </div>
		
		  <textarea name="description"  cols="30" rows="10" class="form-control"><?php echo e($album->description); ?></textarea><br>
		 <div class="fileinput fileinput-new text-center" data-provides="fileinput">
		    <div class="fileinput-new thumbnail img-raised">
		        <img  src="/storage/albums_preview/<?php echo e($album->preview); ?>" alt="...">
			</div>
			<div class="fileinput-preview fileinput-exists thumbnail img-raised"></div>
		    <div>
		        <span class="btn btn-raised btn-round btn-default btn-file">
		            <span class="fileinput-new">выбрать картинку</span>
		            <span class="fileinput-exists">изменить</span>
		            <input type="file"   name="preview">
		        </span>

		        <a href="#pablo" class="btn btn-danger btn-round fileinput-exists" data-dismiss="fileinput"><i class="now-ui-icons ui-1_simple-remove"></i> удалить</a>
		    </div>
		</div> 
		<br>
		<div class="text-center">
	    	<button type="submit" class="btn btn-success btn-lg">Редактировать Альбом</button>
	    </div>

	</form>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminLayouts.admin_master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>