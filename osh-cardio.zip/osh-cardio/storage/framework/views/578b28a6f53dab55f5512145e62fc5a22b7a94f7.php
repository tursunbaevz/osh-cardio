<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.navForPosts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<div class="container">
		<div class="row">
			<div class="col-9" style="margin:auto; margin-top: 100px;">

			<?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<a href="/posts/<?php echo e($post->id); ?>" style="color: #000">
					<h3><?php echo e($post->title); ?></h3>
				</a>
				<p><?php echo str_limit($post->body, 180); ?></p>	
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>