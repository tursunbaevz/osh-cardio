<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.navForPosts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<div id="wrapper-1">
	<div class="gallery-photos">
	<?php $__currentLoopData = $photos->photos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $photo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<a class="gallery-item" href="/storage/photos<?php echo e($photo->album_id); ?>/<?php echo e($photo->image); ?>" style="background-image: url('/storage/photos<?php echo e($photo->album_id); ?>/<?php echo e($photo->image); ?>" alt="image');">
			<img src="/storage/photos<?php echo e($photo->album_id); ?>/<?php echo e($photo->image); ?>" alt="image">
		</a>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</div>
</div>
<script type="text/javascript">
	$(document).ready(function() {
		$('.gallery-photos').magnificPopup({
			delegate: 'a',
			type: 'image',
			tLoading: 'Loading image #%curr%...',
			gallery: {
				enabled: true,
				navigateByImgClick: true,
				preload: [0,1]
			},
		});
	});
</script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
	<!-- Magnific Popup core CSS file -->
	<link rel="stylesheet" href="/css/magnific-popup.css">
	<!-- Magnific Popup core JS file -->
	<script src="/js/magnific-popup.js"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>