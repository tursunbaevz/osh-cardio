<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<div class="page-header" filter-color="orange">
    <div class="page-header-image" style="background-image:url(/img/geny.svg); background-size: center; transform: rotate(-30deg);"></div>
    <div class="container">
        <div class="col-md-4 content-center">
            <div class="card card-login card-plain">
                <form method="POST" action="<?php echo e(route('login')); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="header header-primary text-center">
                        <div class="logo-container">
                            <img src="/img/logo.svg" class="black-shadow">
                        </div>
                    </div>
                    <div class="content">
                        <div class="input-group form-group-no-border input-lg">
                            <span class="input-group-addon">
                                <i class="now-ui-icons ui-1_email-85"></i>
                            </span>
                            <input id="email" type="email" class="form-control <?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email" placeholder="Email" value="<?php echo e(old('email')); ?>" required>
                            <?php if($errors->has('email')): ?>
                            <span class="invalid-feedback">
                                <strong><?php echo e($errors->first('email')); ?></strong>
                            </span>
                            <?php endif; ?>
                        </div>
                        <div class="input-group form-group-no-border input-lg">
                            <span class="input-group-addon">
                                <i class="now-ui-icons objects_key-25"></i>
                            </span>
                            <input id="password" type="password" placeholder="••••••••••••••" class="form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" name="password" required/>
                            <?php if($errors->has('password')): ?>
                            <span class="invalid-feedback">
                                <strong><?php echo e($errors->first('password')); ?></strong>
                            </span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="footer text-center" style="padding: 0">
                        <button type="submit" class="btn btn-primary btn-round btn-lg btn-block">
                            <?php echo e(__('Login')); ?>

                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminLayouts.auth_admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>