<?php $__env->startSection('content'); ?>

<?php echo $__env->make('layouts.nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<div class="page-header  page-header-small">
    <div class="page-header-image" style="background-image: url('img/photo.jpg');"></div>
    <div class="content-center">
        <h1 class="title">Наши Врачи</h1>
    </div>
</div>
<div class="container text-center" style="margin-top: 80px">
    <div class="row" style="margin-bottom: 80px;">
    <?php $__currentLoopData = $doctors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doctor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col">
            <div class="card i-teg text-center" style="width: 18rem; " >
                <img class="card-img-top" src="/storage/doctors_image/<?php echo e($doctor->doctors_image); ?>" alt="Card image cap"><div class="card-body">
                    <h5 class="card-title"><?php echo e(str_limit($doctor->name, 60)); ?></h5>
                    <br>
                    <a class="btn btn-primary btn-round" href="/doctors/<?php echo e($doctor->id); ?>">  
                        подробнее
                    </a>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>

<?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>