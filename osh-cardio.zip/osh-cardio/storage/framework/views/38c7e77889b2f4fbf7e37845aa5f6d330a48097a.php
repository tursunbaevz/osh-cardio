
<div class="main-slider owl-carousel" id="main-slider">
  
  
	<div class="item">
		<div class=" page-header">
			<div class="page-header-image" style="background-image: url('/img/');"></div>
		</div>
	</div>


</div>

<?php $__env->startSection('mainSlider'); ?>
<script type="text/javascript">
  $(document).ready(function(){
    owl = $('#main-slider').owlCarousel({
      singleItem:true,
      items:1,
      autoplay:true,
      responsiveClass: true,
    });
  });
</script>
<?php $__env->stopSection(); ?>