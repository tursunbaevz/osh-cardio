$(document).ready(function(){
	var editor = CKEDITOR.replace( 'editor1',{
	    filebrowserBrowseUrl : '/elfinder/ckeditor' 
	});
});
