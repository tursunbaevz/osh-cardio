<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.navForPosts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

	<div class="page-header page-header-small" style="margin-top: 60px;">
        <div class="page-header-image" data-parallax="true" style="background-image: url('<?php echo e(asset('img/thumbnail/'.$post->image)); ?>');">
        </div>
        <div class="container">
            <div class="content-center">
                <h1 class="title"><?php echo e($post->title); ?></h1>
                <div class="text-center">
                  
                </div>
            </div>
        </div>
    </div>
    <div class="section section-about-us">
        <div class="container">
        	<div class="col-12" style="margin-bottom: 60px;">
            	<p><?php echo $post->body; ?></p>
        	</div>	
        </div>
    </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>