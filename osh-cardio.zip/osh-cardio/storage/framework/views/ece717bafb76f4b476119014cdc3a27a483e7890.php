<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
	<link rel="stylesheet" href="/css/admin_master.css">
	<link rel="stylesheet" href="/css/bootstrap.min.css">
	<link rel="stylesheet" href="<?php echo e(asset('/web-fonts-with-css/css/fontawesome-all.css')); ?>">
	<title>admin dashboard</title>
</head>
<body>

	<?php echo $__env->make('adminLayouts.admin_nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

		<div class="container-fluid">
			
			<div class="col-10" style="margin: auto;"><br>

				
						

					 <?php echo $__env->yieldContent('content'); ?>

	
				

				</div>
			</div>
		</div>

		<script src="<?php echo e(asset('/js/app.js')); ?>"></script>
	
		<?php echo $__env->yieldContent('script'); ?>
		<?php echo $__env->yieldContent('ckeditor'); ?>
		<?php echo $__env->yieldContent('deletePhoto'); ?>
		<?php echo $__env->yieldContent('deleteAlbum'); ?>
		<?php echo $__env->yieldContent('deleteDoctor'); ?>
		<?php echo $__env->yieldContent('upload_image'); ?>

</body>
<script src="/js/bootstrap.min.js"></script>
<script src="/js/jasny-bootstrap.min.js"></script>
</html>
