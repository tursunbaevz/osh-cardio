<?php $__env->startSection('content'); ?>
	

	<a id="btncreate-album" class="btn btn-info" href="/adminpanel/dashboard/albums/create/"><i class="fas fa-plus"></i>&nbsp;&nbsp;Новый Альбом</a>
		<h1 class="title">Галерея</h1>
	<div id="albums" class="text-center">

		

		<div class="row">

			<?php $__currentLoopData = $albums; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $album): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<div class="col-md-4">
				<div class="album-block">
					
				
						<div class="fileinput thumbnail">
							<a href="/adminpanel/dashboard/albums/<?php echo e($album->id); ?>">
								<img class="thumbnail" src="/storage/albums_preview/<?php echo e($album->preview); ?>" alt="<?php echo e($album->name); ?>">
								<div id="block-album-title"></div>
								<div class="card-body">
									<h5><?php echo e(str_limit($album->name, 20)); ?></h5>	
									

								<a id="edit-album" href="<?php echo e(action('Adminpanel\AlbumsController@edit', $album->id)); ?>"><i class="fas fa-edit fa-lg"></i></a>

								<a id="trash-album" class="deletebtn" href="javascript:void(0)" a-data="<?php echo e($album->id); ?>"><i class="fas fa-trash-alt fa-lg"></i></a>

								</div>
							</a>	
						</div>

						<br>
				</div>
			</div>		
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>	
		</div>
	</div>

	
<?php $__env->stopSection(); ?>

<?php $__env->startSection('deleteAlbum'); ?>
	
	<script>
		$(document).on('click', '.deletebtn', function(ev){

		    var albumid = $(this).attr("a-data");
		    var clickedObj = $(this).parent().parent();
		    if (confirm('Все фотографии которые внутри альбома будут удалены!')) {	
			    $.ajax({
			        method: 'DELETE',
			        url: '<?php echo e(url('/adminpanel/dashboard/albums/')); ?>',
			        dataType: 'text',
			        headers: { 'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content') },
			        data: {id:albumid,"_token": "<?php echo e(csrf_token()); ?>"},

			        success: function (data) {
		  				$(clickedObj).fadeOut( "slow", function() {
		    				// удалено
		  				});
			        }
			    });  
			} 
		});

	</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminLayouts.admin_master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>