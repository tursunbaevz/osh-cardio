<!DOCTYPE html>
<html>
<head>
	<title>text</title>
</head>
<link rel="stylesheet" type="text/css" href="/css/owl.carousel.css">
<link rel="stylesheet" type="text/css" href="/css/owl-slider.css">



<body>



<div class="slider">
	<div class="owl-carousel" id="slider">
		<div class="item">hehe</div>
		<div class="item">hehe</div>
		<div class="item">hehe</div>
		<div class="item">hehe</div>
		<div class="item">hehe</div>
		<div class="item">hehe</div>
		<div class="item">hehe</div>
		<div class="item">hehe</div>
		<div class="item">hehe</div>
	</div>
</div>






<script type="text/javascript" src="https://code.jquery.com/jquery-3.3.1.min.js"></script>
<script type="text/javascript" src="/js/owl.carousel.js"></script>
<script type="text/javascript">
	$(document).ready(function(){
		$('#slider').owlCarousel({
			margin: 30,
			items: 4
		}2000);
	});

</script>
</body>
</html>