<footer class="footer footer-default bottom">
	<div class="container footer-text">
		<nav>
			<ul>
				<li>
					<a href="#">
						Page 1
					</a>	                    
					<a href="#">
						Page 2
					</a>
					<a href="#">
						Page 3
					</a>
					<a href="#">
						Page 4
					</a>
				</li>
			</ul>
		</nav>
		<div class="copyright">
			&copy; <script>document.write(new Date().getFullYear())</script>, Created by <a href="#">WebStudio(TODO)</a>
		</div>
	</div>
</footer>