<?php $__env->startSection('content'); ?>
	<div class="col" style="margin: auto;">
	<form method="POST" action="<?php echo e(action('Adminpanel\Posts@update', $post)); ?>" enctype="multipart/form-data">

	  <?php echo e(csrf_field()); ?>


	  <div class="form-group">
	    <br>
	    <input name="title" value="<?php echo e($post->title); ?>" type="text" class="form-control" placeholder="Введите заголовок">
	  </div>
	
	  <textarea id="editor1" name="body"  cols="30" rows="10" class="form-control"><?php echo e($post->body); ?></textarea><br>
	  <label for="feautured_image">Картинка поста</label> <br>
	  <input type="file" name="feautured_image" id="feautured_image"><br><br>
	  <img class="card-img-right flex-auto d-none d-md-block" src=" <?php echo e(asset('img/thumbnail/news/' . $post->imageNews)); ?> "><br>
	  <button type="submit" class="btn btn-primary">Редактировать</button>
	

	<?php if(count($errors)): ?>
		<div class="form-group" style="margin-top: 20px; max-width: 400px;">
			<div class="alert alert-danger">	
				<ul>
					<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<li style="list-style-type: disc;"><?php echo e($error); ?></li>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</ul>
			</div>
		</div>
	<?php endif; ?>

	</form>

	</div>
	
<?php $__env->stopSection(); ?>

<?php $__env->startSection('ckeditor'); ?>
	<script src="<?php echo e(asset('/js/ckeditor/ckeditor.js')); ?>" type="text/javascript" charset="utf-8" ></script>
	<script type="text/javascript" src="/js/ckeditor.js"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminLayouts.admin_master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>