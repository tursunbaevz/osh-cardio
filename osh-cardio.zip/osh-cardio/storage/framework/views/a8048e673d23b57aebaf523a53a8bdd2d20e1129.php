<?php $__env->startSection('content'); ?>

	<div class="col" style="margin: auto; margin-bottom: 50px;">

	<form method="POST" action="<?php echo e(action('Adminpanel\DoctorsController@update', $doctor)); ?>" enctype="multipart/form-data">

		<?php echo e(csrf_field()); ?>


	  	<div class="form-group">
	    <br>
	    	<input name="name" value="<?php echo e($doctor->name); ?>" type="text" class="form-control" placeholder="Введите заголовок">
	  	</div>
		
		<textarea  id="editor1" name="body"  cols="30" rows="10" class="form-control"><?php echo e($doctor->body); ?></textarea><br>

		
		<div class="fileinput fileinput-new text-center" data-provides="fileinput">
		    <div class="fileinput-new thumbnail img-raised">
		        <img  src="/storage/doctors_image/<?php echo e($doctor->doctors_image); ?>" alt="...">
			</div>
			<div class="fileinput-preview fileinput-exists thumbnail img-raised"></div>
		    <div>
		        <span class="btn btn-raised btn-round btn-default btn-file">
		            <span class="fileinput-new">выбрать картинку</span>
		            <span class="fileinput-exists">изменить</span>
		            <input type="file"  name="doctors_image">
		        </span>

		        <a href="#pablo" class="btn btn-danger btn-round fileinput-exists" data-dismiss="fileinput"><i class="now-ui-icons ui-1_simple-remove"></i> удалить</a>
		    </div>
		</div> 
		<br>
		<div class="text-center">
	    	<button type="submit" class="btn btn-success btn-lg">Создать</button>
	    </div>

		


		<?php if(count($errors)): ?>
			<div class="form-group" style="margin-top: 20px; max-width: 400px;">
				<div class="alert alert-danger">	
					<ul>
						<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<li style="list-style-type: disc;"> <?php echo e($error); ?> </li>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</ul>
				</div>
			</div>
		<?php endif; ?>

	</form>
</div>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('ckeditor'); ?>
	<script src="<?php echo e(asset('/js/ckeditor/ckeditor.js')); ?>" type="text/javascript" charset="utf-8" ></script>
	<script type="text/javascript" src="/js/ckeditor.js"></script>	
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminLayouts.admin_master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>