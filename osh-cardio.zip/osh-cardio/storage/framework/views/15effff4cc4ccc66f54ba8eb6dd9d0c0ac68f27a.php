<?php $__env->startSection('content'); ?>
	
	<h1><?php echo e($album->name); ?></h1>
	<a class="btn btn-primary" href="<?php echo e('/adminpanel/dashboard/albums'); ?>">назад</a>
	<a class="btn btn-info" href="/adminpanel/dashboard/photos/create/<?php echo e($album->id); ?>">создать фото для альбома</a>
	<p style="margin-top: 10px;"><?php echo e($album->description); ?></p>
	<hr>
	<div class="row text-center">	
		<?php $__currentLoopData = $album->photos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $photo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<div class="col-xs-6">
				<div class="photo-block">
					<a class="deletebtn" href="javascript:void(0)" p-data="<?php echo e($photo->id); ?>"><i class="fas fa-times"></i></a>
					<img id="photo-image" class="thumbnail" src="/storage/photos<?php echo e($photo->album_id); ?>/<?php echo e($photo->image); ?>" alt="image">
				</div>
			</div>		
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</div>

	

<?php $__env->stopSection(); ?>

<?php $__env->startSection('deletePhoto'); ?>


<script>
	$(document).on('click', '.deletebtn', function(ev){
	    var photoid = $(this).attr("p-data");
	    var clickedObj = $(this).parent().parent();
	    if (confirm('Вы уверены?')) {	
		    $.ajax({
		        method: 'DELETE',
		        url: '<?php echo e(url('/adminpanel/dashboard/albums/photo')); ?>',
		        dataType: 'text',
		        headers: { 'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content') },
		        data: {id:photoid,"_token": "<?php echo e(csrf_token()); ?>"},

		        success: function (data) {
	  				$(clickedObj).fadeOut( "slow", function() {
	    				// удалено
	  				});
		        }
		    });  
		} 
	});

</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminLayouts.admin_master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>