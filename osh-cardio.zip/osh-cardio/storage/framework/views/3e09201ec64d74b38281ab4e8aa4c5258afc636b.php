<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<div class="page-header  page-header-small">
	<div class="page-header-image" style="background-image: url('img/photo.jpg');"></div>
	<div class="content-center">
		<h1 class="title">Наши услуги</h1>
	</div>
</div>
<div class="container" style="margin-top: 80px">
	<div class="row">
	<?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<div class="col-md-4">
			<div class="card card-pricing card-background card-raised" style="background-image: url(<?php echo e(asset('img/thumbnail/services/grid/' . $service->imageGrid)); ?>);">
				<div class="card-body">    
					<div class="more-services" style="margin-top: 100px;">
						<h3 class="category text-info center-block-btn" style ="text-transform: uppercase;">
							<?php echo str_limit($service->title, 35); ?>

						</h3><br><br>
						<a class="btn icon-small btn-round m-style" href="/services/<?php echo e($service->id); ?>">	
							подробнее
						</a>
					</div>                   
				</div>
			</div>
		</div>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</div>
</div>
<div class="pagination" style="margin: 50px auto;">
	<?php echo e($services->links()); ?>	
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>