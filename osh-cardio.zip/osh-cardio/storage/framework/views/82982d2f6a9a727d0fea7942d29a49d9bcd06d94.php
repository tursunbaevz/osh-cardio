<?php $__env->startSection('content'); ?>

	
	<?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		
	<div class="col-md-9">
	  <div class="card flex-md-row mb-4 box-shadow h-md-250">

	    <div class="card-body d-flex flex-column align-items-start">

	      <strong class="d-inline-block mb-2 text-primary">World</strong>

	      <h3 class="mb-0">
	        <a class="text-dark" href="/posts/<?php echo e($post->id); ?>"><?php echo str_limit($post->title, 50); ?></a>
	      </h3>

	      <div class="mb-1 text-muted"><?php echo e(($post->created_at)->diffForHumans()); ?></div>
	      <p class="card-text mb-auto"><?php echo str_limit($post->body, 180); ?></p>
	      <a href="/posts/<?php echo e($post->id); ?>">Читать дальше</a>

	    </div>

		<a href="/posts/<?php echo e($post->id); ?>">
	    <img class="card-img-right flex-auto d-none d-md-block" alt="Thumbnail [200x250]" src=" <?php echo e(asset('img/thumbnail/' . $post->image)); ?> "></a>
	    

	  </div>
	</div>

	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

	<div class="pagination" style="margin: 50px auto;">
		<?php echo e($posts->links()); ?>	
	</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.postGrid', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>