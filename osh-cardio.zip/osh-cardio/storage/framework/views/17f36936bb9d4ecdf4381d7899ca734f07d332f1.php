<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<div class="page-header  page-header-small">
	<div class="page-header-image" style="background-image: url('img/photo.jpg');"></div>
	<div class="content-center">
		<h1 class="title">Новости</h1>
	</div>
</div>
<div class="container" style="margin-top: 80px">
	<div class="row">
	<?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<div class="col-md-9" style="margin: auto;">
			<div class="card-1 flex-md-row mb-4 h-md-250 card-raised">
				<div class="card-body-1 d-flex flex-column-1 align-items-start">
					<strong class="d-inline-block mb-2 text-primary">World</strong>
					<h3 class="mb-0">
						<a class="text-dark" href="/posts/<?php echo e($post->id); ?>"><?php echo str_limit($post->title, 50); ?></a>
					</h3>
					<div class="mb-1 text-muted"><?php echo e(($post->created_at)->diffForHumans()); ?></div>
					<p class="card-text mb-auto"><?php echo str_limit(strip_tags($post->body), 180); ?></p>
					<a href="/posts/<?php echo e($post->id); ?>">Читать дальше</a>
				</div>
				<img class="card-img-right flex-auto d-none d-md-block" src=" <?php echo e(asset('img/thumbnail/grid/' . $post->imageGrid)); ?> ">
			</div>
		</div>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</div>
</div>
<div class="pagination" style="margin: 50px auto;">
	<?php echo e($posts->links()); ?>	
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>