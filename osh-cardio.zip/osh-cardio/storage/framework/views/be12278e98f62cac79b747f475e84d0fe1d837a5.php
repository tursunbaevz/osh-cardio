<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.navForPosts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<div class="container">
	<div class="row">
		<div class="col-9" style="margin:auto; margin-top: 100px;">
		
			<h3><?php echo e($show->title); ?></h3>
			<p><?php echo $show->body; ?></p>
			
		</div>
	</div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>