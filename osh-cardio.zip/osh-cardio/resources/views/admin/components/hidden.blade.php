<label>
	{{Form::hidden($name, $value, $attributes)}}
</label>